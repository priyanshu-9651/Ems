import React from 'react';
import LoginForm from './components/LoginForm';
import './styles/global.css';
import './styles/LoginForm.css';
import FilterBar from './components/events/user/FilterBar';
import EventsPage from './components/events/user/EventsPage';
import EventDetails from './components/events/user/EventDetails';
import 'bootstrap/dist/css/bootstrap.min.css';
import EventForm from './components/events/admin/EventForm';
import Navbar from './components/navbar';
import { CalendarIcon } from './components/Icons';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './components/home/HomePage';
import Footer from './components/home/Footer';
import { AdminSidebar } from './components/dashboard/AdminSidebar';
import { AdminDashboard } from './components/dashboard/AdminDashboard';
import { AdminEvents } from './components/dashboard/AdminEvents';
import UserProfileView from './components/Users/UserProfileView';

function App() {
  return (
    <div>
      <div>
        <Router>
          <Navbar />
          {/* <AdminEvents /> */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/EventsPage" element={<EventsPage />} />
            <Route path="/event/:id" element={<EventDetails />} />
            {/* <Route path="/admin" element={<LoginForm />} /> */}
            <Route path="/addevent" element={<EventForm />} />
            <Route path="/admin/login" element={<LoginForm adminOnly={true} />} />

            <Route
              path="/admin"
              element={
                (localStorage.getItem('role') && localStorage.getItem('role').toUpperCase() === 'ADMIN') ? (
                  <div className="d-flex">
                    <AdminSidebar />
                    <div style={{ marginLeft: '220px', width: '100%' }}>
                      <AdminDashboard />
                    </div>
                  </div>
                ) : (
                  <Navigate to="/admin/login" replace />
                )
              }
            />
            <Route path="/userprofile" element={<UserProfileView />} />
          </Routes>
        </Router>
      </div>

      <div>
        <Footer />
      </div>
    </div>
  );
}

export default App;
