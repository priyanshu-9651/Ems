// API Configuration
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api/auth';

// Generic API request handler
const makeRequest = async (endpoint, options = {}) => {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...options.headers,
      },
      ...options,
    });

    const data = await response.json().catch(() => ({}));

    return {
      success: response.ok,
      status: response.status,
      data,
      error: !response.ok
        ? data.error || data.message || `Server error: ${response.status}`
        : null,
    };
  } catch (error) {
    return {
      success: false,
      status: 0,
      data: null,
      error: 'Network error. Please check your connection.',
    };
  }
};

// Auth API functions


export const logoutUser = async () => {
  return makeRequest('/logout', {
    method: 'GET',
  });
};

export const registerUser = async (name, email, password, role) => {
  return makeRequest('/register', {
    method: 'POST',
    body: JSON.stringify({
      FullName: name,
      Email: email,
      Password: password,
      Role: role.toUpperCase()
    }),
  });
};

export const loginUser = async (email, password, role) => {
  return makeRequest('/login', {
    method: 'POST',
    body: JSON.stringify({
      Email: email,
      Password: password,
      Role: role.toUpperCase()
    }),
  });
};
