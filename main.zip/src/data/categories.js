const CATEGORIES = [
  { name: 'Music', icon: '🎵' },
  { name: 'Food & Drink', icon: '🍔' },
  { name: 'Technology', icon: '💻' },
  { name: 'Arts & Culture', icon: '🎨' },
  { name: 'Sports', icon: '🏅' },
  { name: 'Business', icon: '💼' },
];

export default CATEGORIES;
