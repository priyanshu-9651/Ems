import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const navigation = [
  { name: 'Dashboard', href: '/admin' },
  { name: 'Events', href: '/admin/EventsPage' },
  { name: 'Tasks', href: '/admin/EventsPage' },
  { name: 'Settings', href: '/admin/EventsPage' },
];

export function AdminSidebar() {
  const location = useLocation();

  return (
    <div
      className="d-flex flex-column vh-100 bg-light border-end"
      style={{ width: '220px', position: 'fixed' }}
    >
      <div className="p-3 border-bottom">
        <h4 className="m-0">EventManager</h4>
      </div>
      <nav className="nav flex-column p-2">
        {navigation.map((item) => {
          const isActive =
            location.pathname === item.href ||
            (item.href !== '/admin' && location.pathname.startsWith(item.href));
          return (
            <Link
              key={item.name}
              to={item.href}
              className={`nav-link ${
                isActive ? 'active bg-primary text-white rounded' : 'text-dark'
              }`}
              style={{ marginBottom: '5px' }}
            >
              {item.name}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
